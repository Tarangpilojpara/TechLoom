import React from 'react'
import './Orders.css'

const Orders = () => {
  return (
    <div>
      
    </div>
  )
}


export default Orders
