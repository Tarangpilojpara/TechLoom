import basket_icon from './basket_icon.png'
// import logo from './logo.png'
import logo from './logo2.png'
import header_img from './header_img.png'
import search_icon from './search_icon.png'
import menu_1 from './menu_1.jpg'
import menu_2 from './menu_2.jpg'
import menu_3 from './menu_3.jpg'
import menu_4 from './menu_4.png'
import menu_5 from './menu_5.png'
import menu_6 from './menu_6.jpg'
import menu_7 from './menu_7.jpg'
import menu_8 from './menu_8.jpg'

import food_1 from './food_1.jpg'
import food_2 from './food_2.webp'
import food_3 from './food_3.webp'
import food_4 from './food_4.webp'
import food_5 from './food_5.jpg'
import food_6 from './food_6.webp'
import food_7 from './food_7.jpg'
import food_8 from './food_8.jpg'
import food_9 from './food_9.jpg'
import food_10 from './food_10.jpg'
import food_11 from './food_11.jpg'
import food_12 from './food_12.jpg'
import food_13 from './food_13.webp'
import food_14 from './food_14.webp'
import food_15 from './food_15.webp'
import food_16 from './food_16.webp'
import food_17 from './food_17.jpg'
import food_18 from './food_18.webp'
import food_19 from './food_19.webp'
import food_20 from './food_20.jpg'
import food_21 from './food_21.jpg'
import food_22 from './food_22.avif'
import food_23 from './food_23.png'
import food_24 from './food_24.jpg'
import food_25 from './food_25.png'
import food_26 from './food_26.webp'
import food_27 from './food_27.jpg'
import food_28 from './food_28.jpg'
import food_29 from './food_29.jpg'
import food_30 from './food_30.jpg'
import food_31 from './food_31.webp'
import food_32 from './food_32.webp'

import add_icon_white from './add_icon_white.png'
import add_icon_green from './add_icon_green.png'
import remove_icon_red from './remove_icon_red.png'
import app_store from './app_store.png'
import play_store from './play_store.png'
import linkedin_icon from './linkedin_icon.png'
import facebook_icon from './facebook_icon.png'
import twitter_icon from './twitter_icon.png'
import cross_icon from './cross_icon.png'
import selector_icon from './selector_icon.png'
import rating_starts from './rating_starts.png'
import profile_icon from './profile_icon.png'
import bag_icon from './bag_icon.png'
import logout_icon from './logout_icon.png'
import parcel_icon from './parcel_icon.png'

export const assets = {
    logo,
    basket_icon,
    header_img,
    search_icon,
    rating_starts,
    add_icon_green,
    add_icon_white,
    remove_icon_red,
    app_store,
    play_store,
    linkedin_icon,
    facebook_icon,
    twitter_icon,
    cross_icon,
    selector_icon,
    profile_icon,
    logout_icon,
    bag_icon,
    parcel_icon
}

export const menu_list = [
    {
        menu_name: "Ipad",
        menu_image: menu_1
    },
    {
        menu_name: "Monitor",
        menu_image: menu_2
    },
    {
        menu_name: "Laptops",
        menu_image: menu_3
    },
    {
        menu_name: "Headphones",
        menu_image: menu_4
    },
    {
        menu_name: "Air-Pods",
        menu_image: menu_5
    },
    {
        menu_name: "SmartWatches",
        menu_image: menu_6
    },
    {
        menu_name: "Keybord-Mouse",
        menu_image: menu_7
    },
    {
        menu_name: "Mobiles",
        menu_image: menu_8
    }]

export const food_list = [
    {
        _id: "1",
        name: "Ipad pro M1",
        image: food_1,
        price: 399,
        description: "Experience pro-level performance in an ultra-slim tablet.",
        category: "Ipad"
    },
    {
        _id: "2",
        name: "Ipad",
        image: food_2,
        price: 299,
        description: "Blazing-fast performance meets stunning display and design.",
        category: "Ipad"
    },
    {   
        _id: "3",
        name: "Ipad pro M2",
        image: food_3,
        price: 499,
        description: "Smooth multitasking, stunning visuals, seamless experience.",
        category: "Ipad"
    }, {
        _id: "4",
        name: "Ipad mini",
        image: food_4,
        price: 189,
        description: "Exceptional speed, incredible display, unmatched versatility.",
        category: "Ipad"
    }, {
        _id: "5",
        name: "HP Monitor",
        image: food_5,
        price: 290,
        description: "Crisp visuals, smooth performance, built for productivity.",
        category: "Monitor"
    }, {
        _id: "6",
        name: "ThinkCeter",
        image: food_6,
        price: 199,
        description: "Fast refresh rates for ultra-smooth competitive gaming.",
        category: "Monitor"
    }, {
        _id: "7",
        name: "Pro Display RDX",
        image: food_7,
        price: 599,
        description: "Color-accurate displays made for design perfection.",
        category: "Monitor"
    }, {
        _id: "8",
        name: "DELL Vision",
        image: food_8,
        price: 249,
        description: "Your workspace, elevated with vivid color precision.",
        category: "Monitor"
    }, {
        _id: "9",
        name: "MacBook Pro M2",
        image: food_9,
        price: 1999,
        description: "Sleek design, powerful performance, all-day battery life.",
        category: "Laptops"
    }, {
        _id: "10",
        name: "HP Pavelion",
        image: food_10,
        price: 799,
        description: "owerful, portable, and perfect for everyday tasks.",
        category: "Laptops"
    }, {
        _id: "11",
        name: "DELL EliteBook",
        image: food_11,
        price: 499,
        description: "Sleek design meets reliable performance on the go.",
        category: "Laptops"
    }, {
        _id: "12",
        name: "Asus A4 ProBook",
        image: food_12,
        price: 599,
        description: "Game-ready speed with high-performance graphics.",
        category: "Laptops"
    },
    {
        _id: "13",
        name: "Sony WH-1000XM",
        image: food_13,
        price: 199,
        description: "Clear audio, sleek design, ultimate listening experience.",
        category: "Headphones"
    },
    {
        _id: "14",
        name: "boAt immortal 300",
        image: food_14,
        price: 180,
        description: "Crystal-clear mic, immersive surround gaming audio.",
        category: "Headphones"
    }, {
        _id: "15",
        name: "Apple AirPods Max",
        image: food_15,
        price: 1299,
        description: "Seamless sound, effortless connection—only with Apple.",
        category: "Headphones"
    }, {
        _id: "16",
        name: "Sony WH-CH540",
        image: food_16,
        price: 199,
        description: "Affordable, durable, and surprisingly powerful.",
        category: "Headphones"
    }, {
        _id: "17",
        name: "Air Pods Pro",
        image: food_17,
        price: 499,
        description: "Experience studio-quality sound in your ears.",
        category: "Air-Pods"
    }, {
        _id: "18",
        name: "Galaxy Buds 3",
        image: food_18,
        price: 299,
        description: "Block distractions with active noise cancellation tech.",
        category: "Air-Pods"
    }, {
        _id: "19",
        name: "Noise Buds 4S",
        image: food_19,
        price: 199,
        description: "Sweatproof, secure, and perfect for active lifestyles.",
        category: "Air-Pods"
    }, {
        _id: "20",
        name: "Realme Buds Pro",
        image: food_20,
        price: 149,
        description: "Compact, wireless, and packed with powerful sound.",
        category: "Air-Pods"
    }, {
        _id: "21",
        name: "Pixel Watch 2",
        image: food_21,
        price: 899,
        description: "Stay connected, fit, and organized—right from your wrist.",
        category: "SmartWatches"
    }, {
        _id: "22",
        name: "Galaxy Watch FE",
        image: food_22,
        price: 799,
        description: "Smart technology meets timeless Samsung design.",
        category: "SmartWatches"
    }, {
        _id: "23",
        name: "Galaxy Watch 4",
        image: food_23,
        price: 899,
        description: "Control your day with just a glance.",
        category: "SmartWatches"
    }, {
        _id: "24",
        name: "Apple Series 10",
        image: food_24,
        price: 999,
        description: "Smarter, faster, and more powerful than ever before.",
        category: "SmartWatches"
    },
    {
        _id: "25",
        name: "Portronics Bubble",
        image: food_25,
        price: 149,
        description: "Comfortable typing with precise, responsive keys.",
        category: "Keybord-Mouse"
    },
    {
        _id: "26",
        name: "ZEBRONICS",
        image: food_26,
        price: 129,
        description: "RGB backlighting with programmable macro keys.",
        category: "Keybord-Mouse"
    }, {
        _id: "27",
        name: "Portronics Z4",
        image: food_27,
        price: 149,
        description: "Ultra-fast clicks with precision tracking for gamers.",
        category: "Keybord-Mouse"
    }, {
        _id: "28",
        name: "Logi Tech",
        image: food_28,
        price: 139,
        description: "Comfortable grip with enhanced tracking technology.",
        category: "Keybord-Mouse"
    }, {
        _id: "29",
        name: "Iphone 15Pro",
        image: food_29,
        price: 1699,
        description: "Titanium design meets next-level Apple performance.",
        category: "Mobiles"
    }, {
        _id: "30",
        name: "Samsung S25 ultra",
        image: food_30,
        price: 1699,
        description: "Ultra speed. Ultra clarity. Ultra everything.",
        category: "Mobiles"
    }, {
        _id: "31",
        name: "Pixel 6",
        image: food_31,
        price: 999,
        description: "Smart, secure, and powered by Google Tensor.",
        category: "Mobiles"
    }, {
        _id: "32",
        name: "Galaxy Fold 6",
        image: food_32,
        price: 1299,
        description: "Unfold the future with next-gen foldable innovation.",
        category: "Mobiles"
    }
]
