import React from 'react'
import './Header.css'

const Header = () => {
  return (
    <div className='header'>
      <div className="header-contents">
        <h2>Innovate Your Life with the Latest Tech</h2>
        <p>Discover the latest electronics designed to upgrade your lifestyle.Top brands, best deals, and fast delivery—all in one place.</p>
        <button>View Products</button>
      </div>
    </div>
  )
}

export default Header
