// import React, { useEffect, useState } from "react";
// import { useSearchParams, useNavigate } from "react-router-dom";
// import "./Verify.css";

// const Verify = () => {
//   const [searchParams] = useSearchParams();
//   const navigate = useNavigate();
//   const [message, setMessage] = useState("Verifying your payment...");

  
//   const sessionId = searchParams.get("session_id");

//   useEffect(() => {
//     if (!sessionId) {
//       setMessage("Invalid payment data.");
//       return;
//     }

//     const verifyPayment = async () => {
//       try {
//         console.log("Verifying with session_id:", sessionId);

//         const res = await fetch(
//           `${import.meta.env.VITE_API_URL}/api/orders/verify`,
//           {
//             method: "POST",
//             headers: { "Content-Type": "application/json" },
//             body: JSON.stringify({ sessionId }),
//           }
//         );

//         const data = await res.json();

//         if (data.success) {
//           setMessage("Payment Successful! Thank you for your order.");
//           setTimeout(() => navigate("/orders"), 3000);
//         } else {
//           setMessage("Payment Failed or Cancelled.");
//           setTimeout(() => navigate("/cart"), 3000);
//         }
//       } catch (err) {
//         console.error(err);
//         setMessage("Error verifying payment.");
//       }
//     };

//     verifyPayment();
//   }, [sessionId, navigate]);

//   return (
//     <div className="verify-container">
//       <div className="verify-box">
//         <h2>{message}</h2>
//         <div className="loader"></div>
//         <p>Please wait while we process your payment...</p>
//       </div>
//     </div>
//   );
// };

// export default Verify;
import React, { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import "./Verify.css";

const Verify = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [message, setMessage] = useState("Verifying your payment...");

  const success = searchParams.get("success");
  const orderId = searchParams.get("orderId");

  useEffect(() => {
    if (!success || !orderId) {
      setMessage("Invalid payment data.");
      return;
    }

    const verifyPayment = async () => {
      try {
        console.log("Verifying with orderId:", orderId);

        const res = await fetch(
          `${import.meta.env.VITE_API_URL}/api/orders/verify`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ success, orderId }),
          }
        );

        const data = await res.json();

        if (data.success) {
          setMessage("Payment Successful! Thank you for your order.");
          setTimeout(() => navigate("/orders"), 3000);
        } else {
          setMessage("Payment Failed or Cancelled.");
          setTimeout(() => navigate("/cart"), 3000);
        }
      } catch (err) {
        console.error(err);
        setMessage("Error verifying payment.");
      }
    };

    verifyPayment();
  }, [success, orderId, navigate]);

  return (
    <div className="verify-container">
      <div className="verify-box">
        <h2>{message}</h2>
        <div className="loader"></div>
        <p>Please wait while we process your payment...</p>
      </div>
    </div>
  );
};

export default Verify;
