// import { CurrencyCodes } from "validator/lib/isISO4217.js";
// import orderModel from "../models/orderModel.js";
// import userModel from "../models/userModel.js"
// import Stripe from "stripe"

// const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)


// // placing user ordr from frontend
// const placeOrder = async (req,res) => {

//     const frontend_url = "http://localhost:5173"

//     try {
//         const newOrder = new orderModel({
//             userId:req.body.userId,
//             items:req.body.items,
//             amount:req.body.amount,
//             address:req.body.address
//         })
//         await newOrder.save();
//         await userModel.findByIdAndUpdate(req.body.userId,{cartData:{}});

//         const line_items = req.body.item.map((item) =>({
//             price_data:{
//                 Currency:"us",
//                 product_data:{
//                     name:item.name
//                 },
//                 unit_amount:item.price*100
//             },
//             quantity:item.quantity
//         }))
//         line_items.push({
//             price_data:{
//                 Currency:"us",
//                 product_data:{
//                     name:"Delivery Charges"
//                 },
//                 unit_amount:2*100
//             },
//             quantity:1
//         })

//         const session = await stripe.checkout.sessions.create({
//             line_items:line_items,
//             mod:'payment',
//             success_url:`${frontend_url}/verify?success=true&orderId=${newOrder._id}`,
//             cancel_url:`${frontend_url}/verify?success=false&orderId=${newOrder._id}`
//         })

//         res.json({success:true,session_url:session_url})
//     } catch (error) {
//         console.log(error);
//         res.json({success:false,message:"Error"})
        
//     }
// }

// export {placeOrder}

//--------------------------------------------------------------------------------------------------
// backend/controllers/orderController.js
// import orderModel from "../models/orderModel.js";
// import Order from "../models/orderModel.js";
// import Stripe from "stripe";


// const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// export const placeOrder = async (req, res) => {
//   try {
//     const userId = req.userId; // from auth middleware
//     if (!userId) return res.status(401).json({ success: false, message: "User ID not found" });

//     const { items, amount, address } = req.body;
//     if (!items || items.length === 0) return res.status(400).json({ success: false, message: "Cart is empty" });
//     if (!amount || amount <= 0) return res.status(400).json({ success: false, message: "Invalid amount" });
//     if (!address) return res.status(400).json({ success: false, message: "Address is required" });

//     // Save order
//     const newOrder = new Order({
//       userId,
//       items,
//       amount,
//       address,
//       payment: false,
//       status: "Pending"
//     });
//     await newOrder.save();

//     // Stripe line items
//     const line_items = items.map(item => ({
//       price_data: {
//         currency: "usd",
//         product_data: { name: item.name },
//         unit_amount: Math.round(item.price * 100),
//       },
//       quantity: item.quantity,
//     }));

//     // Add delivery fee
//     line_items.push({
//       price_data: {
//         currency: "usd",
//         product_data: { name: "Delivery Charges" },
//         unit_amount: 2 * 100,
//       },
//       quantity: 1,
//     });

// //     // Create Stripe session
// //     const session = await stripe.checkout.sessions.create({
// //   payment_method_types: ["card"],
// //   line_items,
// //   mode: "payment",
// //   success_url: `${process.env.FRONTEND_URL}/verify?success=true&orderId=${newOrder._id}`,
// //   cancel_url: `${process.env.FRONTEND_URL}/verify?success=false&orderId=${newOrder._id}`,

// // });
// // Create Stripe session
// const successUrl = `${process.env.FRONTEND_URL}/verify?success=true&orderId=${newOrder._id}`;
// const cancelUrl = `${process.env.FRONTEND_URL}/verify?success=false&orderId=${newOrder._id}`;

// console.log("Stripe redirect URLs:", { successUrl, cancelUrl }); // 👈 debug log

// const session = await stripe.checkout.sessions.create({
//   payment_method_types: ["card"],
//   line_items,
//   mode: "payment",
//   success_url: successUrl,
//   cancel_url: cancelUrl,
// });


//     res.status(201).json({ success: true, stripeSessionUrl: session.url });
//   } catch (err) {
//     console.error("Order creation error:", err);
//     res.status(500).json({ success: false, message: "Error creating order", error: err.message });
//   }
// };

// // const verifyOrder = async (req,res) => {
// //   const {orderId,success} = req.body;
// //   try{
// //     if (success=="true"){
// //       await orderModel.findByIdAndUpdate(orderId,{payment:true});
// //       res.json({success:true,message:"paid"}) 
// //     }
// //     else{
// //       await orderModel.findByIdAndDelete(orderId);
// //       res.json({success:false,message:"Not Paid"})
// //     }
// //   }
// //   catch (error) {
// //     console.log(error);
// //     res.json({success:false,message:"Error"})
    
// //   }
// // }


// // Verify Order
// export const verifyOrder = async (req, res) => {
//   const { orderId, success } = req.body; // data from frontend POST request

//   try {
//     if (success === "true") {
//       await orderModel.findByIdAndUpdate(orderId, { payment: true });
//       res.json({ success: true, message: "Payment successful" });
//     } else {
//       await orderModel.findByIdAndDelete(orderId);
//       res.json({ success: false, message: "Payment failed or cancelled" });
//     }
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ success: false, message: "Error verifying order" });
//   }
// };

// import Order from "../models/orderModel.js";
// import Stripe from "stripe";
// import dotenv from "dotenv";
// import mongoose from "mongoose";

// dotenv.config();

// const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// // ===================== PLACE ORDER =====================
// export const placeOrder = async (req, res) => {
//   try {
//     const userId = req.userId; // from auth middleware
//     if (!userId) {
//       return res.status(401).json({ success: false, message: "User ID not found" });
//     }

//     const { items, amount, address } = req.body;

//     if (!items || items.length === 0) {
//       return res.status(400).json({ success: false, message: "Cart is empty" });
//     }
//     if (!amount || amount <= 0) {
//       return res.status(400).json({ success: false, message: "Invalid amount" });
//     }
//     if (!address) {
//       return res.status(400).json({ success: false, message: "Address is required" });
//     }

//     // Save order
//     const newOrder = new Order({
//       userId,
//       items,
//       amount,
//       address,
//       payment: false,
//       status: "Pending",
//     });
//     await newOrder.save();

//     // Stripe line items
//     const line_items = items.map((item) => ({
//       price_data: {
//         currency: "usd",
//         product_data: { name: item.name },
//         unit_amount: Math.round(item.price * 100),
//       },
//       quantity: item.quantity,
//     }));

//     // Add delivery fee
//     line_items.push({
//       price_data: {
//         currency: "usd",
//         product_data: { name: "Delivery Charges" },
//         unit_amount: 200, // $2 delivery fee
//       },
//       quantity: 1,
//     });

//     // Redirect URLs
//     const successUrl = `${process.env.FRONTEND_URL}/verify?success=true&orderId=${newOrder._id}`;
//     const cancelUrl = `${process.env.FRONTEND_URL}/verify?success=false&orderId=${newOrder._id}`;

//     console.log("✅ Stripe redirect URLs:", { successUrl, cancelUrl }); // debug log

//     // Create Stripe session
//     const session = await stripe.checkout.sessions.create({
//       payment_method_types: ["card"],
//       line_items,
//       mode: "payment",
//       success_url: successUrl,
//       cancel_url: cancelUrl,
//     });

//     return res.status(201).json({ success: true, stripeSessionUrl: session.url });
//   } catch (err) {
//     console.error("❌ Order creation error:", err);
//     return res.status(500).json({
//       success: false,
//       message: "Error creating order",
//       error: err.message,
//     });
//   }
// };

// // ===================== VERIFY ORDER =====================
// // export const verifyOrder = async (req, res) => {
// //   const { orderId, success } = req.body;

// //   try {
// //     console.log("🔎 Verifying order:", { orderId, success });

// //     if (!orderId) {
// //       return res.status(400).json({ success: false, message: "Missing orderId" });
// //     }

// //     if (success === "true") {
// //       const updatedOrder = await Order.findByIdAndUpdate(
// //         orderId,
// //         { payment: true, status: "Paid" },
// //         { new: true }
// //       );

// //       if (!updatedOrder) {
// //         return res.status(404).json({ success: false, message: "Order not found" });
// //       }

// //       return res.json({ success: true, message: "Payment successful", order: updatedOrder });
// //     } else {
// //       await Order.findByIdAndDelete(orderId);
// //       return res.json({ success: false, message: "Payment failed or cancelled" });
// //     }
// //   } catch (error) {
// //     console.error("❌ Verify order error:", error.message);
// //     return res.status(500).json({ success: false, message: "Error verifying order" });
// //   }
// // };
// export const verifyOrder = async (req, res) => {
//   const { orderId, success } = req.body;

//   if (!mongoose.Types.ObjectId.isValid(orderId)) {
//     return res.status(400).json({ success: false, message: "Invalid orderId" });
//   }

//   try {
//     if (success === "true") {
//       await Order.findByIdAndUpdate(orderId, { payment: true });
//       return res.json({ success: true, message: "Payment successful" });
//     } else {
//       await Order.findByIdAndDelete(orderId);
//       return res.json({ success: false, message: "Payment failed or cancelled" });
//     }
//   } catch (error) {
//     console.error("❌ Verify order error:", error);
//     return res.status(500).json({ success: false, message: "Error verifying order" });
//   }
// };
// import Order from "../models/orderModel.js";
// import Stripe from "stripe";
// import dotenv from "dotenv";
// import orderModel from "../models/orderModel.js";

// dotenv.config();

// const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// // ===================== PLACE ORDER =====================
// export const placeOrder = async (req, res) => {
//   try {
//     const userId = req.userId; // from auth middleware
//     if (!userId) {
//       return res.status(401).json({ success: false, message: "User ID not found" });
//     }

//     const { items, amount, address } = req.body;

//     if (!items || items.length === 0) {
//       return res.status(400).json({ success: false, message: "Cart is empty" });
//     }
//     if (!amount || amount <= 0) {
//       return res.status(400).json({ success: false, message: "Invalid amount" });
//     }
//     if (!address) {
//       return res.status(400).json({ success: false, message: "Address is required" });
//     }

//     // Save order
//     const newOrder = new Order({
//       userId,
//       items,
//       amount,
//       address,
//       payment: false,
//       status: "Pending",
//     });
//     await newOrder.save();

//     // Stripe line items
//     const line_items = items.map((item) => ({
//       price_data: {
//         currency: "usd",
//         product_data: { name: item.name },
//         unit_amount: Math.round(item.price * 100),
//       },
//       quantity: item.quantity,
//     }));

//     // Add delivery fee
//     line_items.push({
//       price_data: {
//         currency: "usd",
//         product_data: { name: "Delivery Charges" },
//         unit_amount: 200, // $2 delivery fee
//       },
//       quantity: 1,
//     });

//     // ✅ Create Stripe session with metadata
//     const session = await stripe.checkout.sessions.create({
//       payment_method_types: ["card"],
//       line_items,
//       mode: "payment",
//       success_url: `${process.env.FRONTEND_URL}/verify?session_id={CHECKOUT_SESSION_ID}`,
//       cancel_url: `${process.env.FRONTEND_URL}/verify?session_id={CHECKOUT_SESSION_ID}`,
//       metadata: { orderId: newOrder._id.toString() }, // <-- attach orderId safely
//     });

//     return res.status(201).json({ success: true, stripeSessionUrl: session.url });
//   } catch (err) {
//     console.error("❌ Order creation error:", err);
//     return res.status(500).json({
//       success: false,
//       message: "Error creating order",
//       error: err.message,
//     });
//   }
// };
// ===================== PLACE ORDER =====================
// export const placeOrder = async (req, res) => {
//   try {
//     const userId = req.userId; // from auth middleware
//     if (!userId) {
//       return res.status(401).json({ success: false, message: "User ID not found" });
//     }

//     const { items, amount, address } = req.body;

//     if (!items || items.length === 0) {
//       return res.status(400).json({ success: false, message: "Cart is empty" });
//     }
//     if (!amount || amount <= 0) {
//       return res.status(400).json({ success: false, message: "Invalid amount" });
//     }
//     if (!address) {
//       return res.status(400).json({ success: false, message: "Address is required" });
//     }

//     // 1️⃣ Save order in MongoDB with default "payment: false"
//     const newOrder = new Order({
//       userId,
//       items,
//       amount,
//       address,
//       payment: false,
//       status: "Pending",
//     });
//     await newOrder.save();

//     // 2️⃣ Prepare Stripe line items
//     const line_items = items.map((item) => ({
//       price_data: {
//         currency: "usd",
//         product_data: { name: item.name },
//         unit_amount: Math.round(item.price * 100), // convert to cents
//       },
//       quantity: item.quantity,
//     }));

//     // Add delivery fee
//     line_items.push({
//       price_data: {
//         currency: "usd",
//         product_data: { name: "Delivery Charges" },
//         unit_amount: 200, // $2 delivery fee
//       },
//       quantity: 1,
//     });

//     // 3️⃣ Create Stripe Checkout session
//     const session = await stripe.checkout.sessions.create({
//       payment_method_types: ["card"],
//       line_items,
//       mode: "payment",
//       success_url: `${process.env.FRONTEND_URL}/verify?session_id={CHECKOUT_SESSION_ID}`,
//       cancel_url: `${process.env.FRONTEND_URL}/verify?session_id={CHECKOUT_SESSION_ID}`,
//       metadata: {
//         orderId: newOrder._id.toString(), // ✅ attach MongoDB orderId to Stripe session
//         userId: userId.toString(),       // optional, helps debugging
//       },
//     });

//     // 4️⃣ Respond with Stripe session URL
//     return res.status(201).json({
//       success: true,
//       stripeSessionUrl: session.url,
//     });
//   } catch (err) {
//     console.error("❌ Order creation error:", err);
//     return res.status(500).json({
//       success: false,
//       message: "Error creating order",
//       error: err.message,
//     });
//   }
// };


// ===================== VERIFY ORDER =====================
// export const verifyOrder = async (req, res) => {
//   const { sessionId } = req.body;

//   try {
//     // ✅ Fetch session from Stripe
//     const session = await stripe.checkout.sessions.retrieve(sessionId);

//     // Get orderId from metadata
//     const orderId = session.metadata.orderId;

//     if (session.payment_status === "paid") {
//       await Order.findByIdAndUpdate(orderId, { payment: true, status: "Confirmed" });
//       return res.json({ success: true, message: "Payment successful" });
//     } else {
//       await Order.findByIdAndDelete(orderId);
//       return res.json({ success: false, message: "Payment failed or cancelled" });
//     }
//   } catch (error) {
//     console.error("❌ Verify order error:", error);
//     return res.status(500).json({ success: false, message: "Error verifying order" });
//   }
// };
// ===================== VERIFY ORDER =====================
// export const verifyOrder = async (req, res) => {
//   const { sessionId } = req.body;

//   try {
//     if (!sessionId) {
//       return res.status(400).json({ success: false, message: "Missing sessionId" });
//     }

//     // 1️⃣ Retrieve session details from Stripe
//     const session = await stripe.checkout.sessions.retrieve(sessionId);

//     if (!session) {
//       return res.status(404).json({ success: false, message: "Session not found" });
//     }

//     // 2️⃣ Get orderId from metadata (we saved it when creating the order)
//     const orderId = session.metadata?.orderId;
//     if (!orderId) {
//       return res.status(400).json({ success: false, message: "Order ID missing in session metadata" });
//     }

//     // 3️⃣ Check payment status
//     if (session.payment_status === "paid") {
//       await Order.findByIdAndUpdate(orderId, { payment: true, status: "Confirmed" });
//       return res.json({ success: true, message: "Payment successful, order updated" });
//     } else {
//       await Order.findByIdAndUpdate(orderId, { payment: false, status: "Failed" });
//       return res.json({ success: false, message: "Payment not completed" });
//     }
//   } catch (error) {
//     console.error("❌ Verify order error:", error);
//     return res.status(500).json({ success: false, message: "Error verifying order" });
//   }
// };

// // user order for frontend
// const userOrders = async (req,res) => {
//   try {
//      const orders = await orderModel.find({userId:req.body.userId});
//      res.json({success:true,data:orders}) 
//   } catch (error) {
//     console.log(error);
//     res.json({success:false,message:"Error"})
    
//   }
// }

// export {userOrders}
import Order from "../models/orderModel.js";
import Stripe from "stripe";
import dotenv from "dotenv";

dotenv.config();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// ===================== PLACE ORDER =====================
export const placeOrder = async (req, res) => {
  try {
    const userId = req.userId; // Make sure auth middleware sets this
    if (!userId) {
      return res.status(401).json({ success: false, message: "User ID not found" });
    }

    const { items, amount, address } = req.body;

    if (!items || items.length === 0) {
      return res.status(400).json({ success: false, message: "Cart is empty" });
    }
    if (!amount || amount <= 0) {
      return res.status(400).json({ success: false, message: "Invalid amount" });
    }
    if (!address) {
      return res.status(400).json({ success: false, message: "Address is required" });
    }

    // 1️⃣ Save order in MongoDB with payment=false
    const newOrder = new Order({
      userId,
      items,
      amount,
      address,
      payment: false,
      status: "Pending",
    });
    await newOrder.save();

    // 2️⃣ Prepare Stripe line items
    const line_items = items.map(item => ({
      price_data: {
        currency: "usd",
        product_data: { name: item.name },
        unit_amount: Math.round(item.price * 100),
      },
      quantity: item.quantity,
    }));

    // Add delivery fee
    line_items.push({
      price_data: {
        currency: "usd",
        product_data: { name: "Delivery Charges" },
        unit_amount: 200, // $2 delivery fee
      },
      quantity: 1,
    });

    // 3️⃣ Create Stripe Checkout session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items,
      mode: "payment",
      success_url: `${process.env.FRONTEND_URL}/verify?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/verify?session_id={CHECKOUT_SESSION_ID}`,
      metadata: { orderId: newOrder._id.toString() },
    });

    // 4️⃣ Return session URL to frontend
    return res.status(201).json({ success: true, stripeSessionUrl: session.url });
  } catch (err) {
    console.error("❌ Order creation error:", err);
    return res.status(500).json({
      success: false,
      message: "Error creating order",
      error: err.message,
    });
  }
};
// ===================== VERIFY ORDER =====================
export const verifyOrder = async (req, res) => {
  const { sessionId } = req.body;

  try {
    if (!sessionId) {
      return res.status(400).json({ success: false, message: "Missing sessionId" });
    }

    // ✅ Retrieve session from Stripe
    const session = await stripe.checkout.sessions.retrieve(sessionId);

    if (!session) {
      return res.status(404).json({ success: false, message: "Session not found" });
    }

    const orderId = session.metadata?.orderId;
    if (!orderId) {
      return res.status(400).json({ success: false, message: "Order ID missing in session metadata" });
    }

    if (session.payment_status === "paid") {
      await Order.findByIdAndUpdate(orderId, { payment: true, status: "Confirmed" });
      return res.json({ success: true, message: "Payment successful, order updated" });
    } else {
      await Order.findByIdAndUpdate(orderId, { payment: false, status: "Failed" });
      return res.json({ success: false, message: "Payment not completed" });
    }
  } catch (error) {
    console.error("❌ Verify order error:", error);
    return res.status(500).json({ success: false, message: "Error verifying order" });
  }
};

// ===================== USER ORDERS =====================
export const userOrders = async (req, res) => {
  try {
    const orders = await Order.find({ userId: req.userId }).sort({ date: -1 });
    res.json({ success: true, data: orders });
  } catch (error) {
    console.error("❌ Fetch user orders error:", error);
    res.status(500).json({ success: false, message: "Error fetching user orders" });
  }
};

