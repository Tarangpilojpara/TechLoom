import techmodel from "../models/techmodel.js";
import fs from 'fs'
import path from "path";

//add tech item

const addTech = async (req,res) => {

    
    let image_filename = `${req.file.filename}`;

    const tech = new techmodel({
        name:req.body.name,
        description:req.body.description,
        price:req.body.price,
        category:req.body.category,
        image:image_filename
    })
    try{
        await tech.save();
        res.json({success:true,message:"Product Added"})
    }catch(error){
        console.log(error)
        res.json({success:false,message:"Error"})
    }
}

//all tech product list
// const listtech = async (req,res) => {
//     try{
//         const tech = await tachmodel.find({});
//         res.json({success:true,data:tech})
//     }catch(error){
//         console.log(error);
//         res.json({success:false,message:"Error"})
//     }
// }
const listtech = async (req, res) => {
  try {
    const tech = await techmodel.find({});
    res.json({ success: true, data: tech });
  } catch (error) {
    console.log(error);
    res.json({ success: false, message: "Error" });
  }
};


//remove tech product

// const removetech = async (req,res) =>{
//     try{
//         const tech = await techmodel.findById(req.body.id);
//         fs.unlike(`uploads/${tech.image}`,()=>{})
        
//         await techmodel.findByIdAndDelete(req.body.id);
//         res.json({success:true,message:"tech removed"})
//     }catch(error){
//         console.log(error);
//         res.json({success:false,message:"Error"})
//     }
// }
const removetech = async (req, res) => {
  try {
    const tech = await techmodel.findById(req.body.id);
    if (!tech) {
      return res.json({ success: false, message: "Tech not found" });
    }

    // Delete file from uploads folder
    fs.unlink(path.join(process.cwd(), "uploads", tech.image), (err) => {
      if (err) {
        console.error("Error deleting file:", err);
      }
    });

    // Delete from DB
    await techmodel.findByIdAndDelete(req.body.id);

    res.json({ success: true, message: "Tech removed" });
  } catch (error) {
    console.log(error);
    res.json({ success: false, message: "Error" });
  }
};

export {addTech,listtech,removetech}