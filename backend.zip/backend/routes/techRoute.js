import express from "express"
import { addTech , listtech , removetech} from "../controllers/techController.js"
import multer from "multer"

const techRouter = express.Router();

//Image Storage Engine

const storage = multer.diskStorage({
    destination:"uploads",
    filename:(req,file,cb)=>{
        return cb(null,`${Date.now()}${file.originalname}`)
    }
})

const upload = multer({storage:storage})

techRouter.post("/add",upload.single("image"),addTech)

// techRouter.post("/add",addTech)
techRouter.get("/list",listtech)
techRouter.post("/remove",removetech);

 




export default techRouter;