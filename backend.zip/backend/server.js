import express from "express"
import cors from "cors"
import { connectDB } from "./config/db.js"
import techRouter from "./routes/techRoute.js"
import userRouter from "./routes/userRoute.js"
import 'dotenv/config'
import cartRouter from "./routes/cartRoute.js"
import orderRouter from "./routes/orderRoute.js"
import  paymentRoutes from "./routes/payment.js"
import dotenv from "dotenv";
dotenv.config();


//app config
const app = express()
const port = 4000

//middleware
app.use(express.json())
app.use(cors())

//db connection
connectDB();

//API endpoint
app.use("/api/tech",techRouter)
app.use("/images",express.static('uploads'))
app.use("/api/user",userRouter)
app.use("/api/cart",cartRouter)
app.use("/api/order",orderRouter)
app.use("/api/orders", orderRouter);
app.use("/api/payment", paymentRoutes);

app.get("/",(req,res)=>{
    res.send("API Working")
})

app.listen(port,()=>{
    console.log(`Server Started on http://localhost:${port}`)
})

//mongodb+srv://tarang-gajjar:20122003@cluster0.e77i2zd.mongodb.net/?