import mongoose from "mongoose";

export const connectDB = async () =>{
    await mongoose.connect('mongodb+srv://tarang-gajjar:20122003@cluster0.e77i2zd.mongodb.net/food-del').then(()=>console.log("DB Connected"));
}